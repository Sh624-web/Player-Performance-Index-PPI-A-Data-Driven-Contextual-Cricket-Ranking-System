All recently added Men's match data in CSV format
=================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All recently added Men's matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.6.0, or 1.7.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2025-02-23 - international - T20 - male - 1473147 - Oman vs United States of America
2025-02-23 - international - T20 - male - 1471825 - Bahrain vs Indonesia
2025-02-23 - international - T20 - male - 1467705 - Ireland vs Zimbabwe
2025-02-23 - international - ODI - male - 1466418 - Pakistan vs India
2025-02-22 - international - T20 - male - 1471824 - Bahrain vs Indonesia
2025-02-22 - international - T20 - male - 1467704 - Zimbabwe vs Ireland
2025-02-22 - international - ODI - male - 1466417 - England vs Australia
2025-02-21 - international - T20 - male - 1473146 - Oman vs United States of America
2025-02-20 - international - T20 - male - 1473145 - Oman vs United States of America
2025-02-20 - international - ODI - male - 1466415 - Bangladesh vs India
2025-02-18 - club - SSH - male - 1444515 - South Australia vs Tasmania
2025-02-18 - club - SSH - male - 1444514 - Queensland vs Western Australia
2025-02-18 - club - SSH - male - 1444513 - New South Wales vs Victoria

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
