All recently added Men's match data in CSV format
=================================================

The background
--------------

As an experiment, after being asked by a user of the site, I started
converting the IPL data from YAML into this CSV format. This then expanded
to include international T20s, for both women and men, before, finally,
expanding again to cover all matches we provide.

This particular zip folder contains the CSV data for...
  All recently added Men's matches
...for which we have data, and is loosely based on the format that Retrosheet
uses for baseball, with some suitable hacks built in.

How you can help
----------------

Providing feedback on the data would be the most helpful. Tell me what you
like and what you don't. Is there anything that is in the JSON data that
you'd like to be included in the CSV? Could something be included in a better
format? General views and comments help, as well as incredibly detailed
feedback. All information is of use to me at this stage. I can only improve
the data if people tell me what does works and what doesn't. I'd like to make
the data as useful as possible but I need your help to do it. Also, which of
the 2 CSV formats do you prefer, this one or the newer "Ashwin" format?
Ideally I'd like to settle on a single CSV format so what should be kept
from each?

Finally, any feedback as to the licence the data should be released under
would be greatly appreciated. Licensing is a strange little world and I'd
like to choose the "right" licence. My basic criteria may be that:

  * the data should be free,
  * corrections are encouraged/required to be reported to the project,
  * derivative works are allowed,
  * you can't just take data and sell it.

Feedback, pointers, comments, etc on licensing are welcome.

The format of the data
----------------------

Full documentation of this CSV format can be found at:
  https://cricsheet.org/format/csv_original/
but the following is a brief summary of the details...

Each file has a 'version', multiple 'info' lines, and multiple 'ball' lines.
'version' is just 1.6.0, or 1.7.0 for now, and will change as I make changes.
The 'info' entries should be fairly self-explanatory but feel free to ask on
Mastodon (@cricsheet@deeden.co.uk) if you're unsure. If you look carefully
you may see some slight hints as to some data we'll be including in the full
data files in the future.

Each 'ball' line has the following fields:

  * The word 'ball' to identify it as such
  * Innings number, starting from 1
  * Over and ball
  * Batting team name
  * Batsman
  * Non-striker
  * Bowler
  * Runs-off-bat
  * Extras
  * Wides
  * No-balls
  * Byes
  * Leg-byes
  * Penalty
  * Kind of wicket, if any
  * Dismissed played, if there was a wicket

Matches included in this archive
--------------------------------

2025-01-29 - club - SSM - male - 1452617 - Auckland vs Central Districts
2025-01-29 - club - SAT - male - 1449658 - Sunrisers Eastern Cape vs MI Cape Town
2025-01-29 - club - ILT - male - 1462196 - Gulf Giants vs Desert Vipers
2025-01-29 - club - BPL - male - 1459574 - Dhaka Capital vs Fortune Barishal
2025-01-29 - club - BPL - male - 1459573 - Rangpur Riders vs Chittagong Kings
2025-01-28 - international - T20 - male - 1439901 - England vs India
2025-01-28 - club - SSM - male - 1452616 - Canterbury vs Northern Districts
2025-01-28 - club - SAT - male - 1449657 - Joburg Super Kings vs Pretoria Capitals
2025-01-28 - club - ILT - male - 1462195 - Dubai Capitals vs Sharjah Warriorz
2025-01-27 - club - SSM - male - 1452615 - Auckland vs Wellington
2025-01-27 - club - SAT - male - 1449656 - Durban's Super Giants vs Paarl Royals
2025-01-27 - club - ILT - male - 1462194 - MI Emirates vs Desert Vipers
2025-01-27 - club - BPL - male - 1459572 - Sylhet Strikers vs Durbar Rajshahi
2025-01-27 - club - BPL - male - 1459571 - Khulna Tigers vs Fortune Barishal
2025-01-27 - club - BBL - male - 1443100 - Sydney Thunder vs Hobart Hurricanes
2025-01-25 - international - Test - male - 1442219 - West Indies vs Pakistan

Further information
-------------------

You can find all of our currently available data at https://cricsheet.org/

You can contact me via the following methods:
  Email   : stephen@cricsheet.org
  Mastodon: @cricsheet@deeden.co.uk
